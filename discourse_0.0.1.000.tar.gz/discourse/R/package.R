#' @useDynLib discourse, .registration = TRUE
#' @importFrom Rcpp evalCpp
"_PACKAGE"
